<?php

namespace MyHordes\Secret\Service;

use MyHordes\Fixtures\Interfaces\FixtureProcessorInterface;

class TownDataService implements FixtureProcessorInterface {

    public function process(array &$data): void
    {
        $data = array_merge_recursive($data, [
            'test' =>  ['name'=>'test', 'label'=>'test town', 'preset' => true, 'ranked' => false, 'orderBy' =>  20, 'help' => 'demo'],
        ]);
    }
}